package JSON;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class JSONCompareDynamic {

    public static void main(String[] args) {
        // Define paths to JSON files inside the package
        String oldFilePath = "Data/json1.json"; // OldFormat file
        String newFilePath = "Data/json2.json"; // NewFormat file
        String outputFilePath = "Data/output.json"; // Output JSON file

        try {
            // Ensure the output directory exists
            File outputDir = new File("Data");
            if (!outputDir.exists()) {
                outputDir.mkdirs(); // Create the directory if it doesn't exist
            }

            // Load files using ClassLoader
            InputStream oldFileStream = getFileFromResource(oldFilePath);
            InputStream newFileStream = getFileFromResource(newFilePath);

            if (oldFileStream != null && newFileStream != null) {
                System.out.println("Comparing files...");

                // Read files as JsonNode
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode oldJson = objectMapper.readTree(oldFileStream);
                JsonNode newJson = objectMapper.readTree(newFileStream);

                // Perform a comparison and generate modified JSON
                JsonNode modifiedJson = compareAndModifyJson(oldJson, newJson);

                // Write the modified JSON to a file
                objectMapper.writerWithDefaultPrettyPrinter().writeValue(new File(outputFilePath), modifiedJson);

                System.out.println("Comparison complete. Modified JSON written to: " + outputFilePath);

            } else {
                System.out.println("One or both JSON files could not be found in the package.");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to get a file from the resource folder
    public static InputStream getFileFromResource(String filePath) {
        return JSONCompareDynamic.class.getClassLoader().getResourceAsStream(filePath);
    }

    // Method to compare and modify NewFormat JSON based on OldFormat JSON
    public static JsonNode compareAndModifyJson(JsonNode oldJson, JsonNode newJson) {
        // Traverse the NewFormat JSON and compare its values dynamically with OldFormat JSON
        traverseAndModify(newJson, oldJson, null, null);
        return newJson;
    }

    // Recursive method to traverse and modify JSON nodes
    public static void traverseAndModify(JsonNode newNode, JsonNode oldJson, ObjectNode parentNode, String fieldName) {
        if (newNode.isObject()) {
            Iterator<String> fieldNames = newNode.fieldNames();
            while (fieldNames.hasNext()) {
                String currentFieldName = fieldNames.next();
                JsonNode fieldValue = newNode.get(currentFieldName);

                // Recursively traverse and modify the field
                traverseAndModify(fieldValue, oldJson, (ObjectNode) newNode, currentFieldName);
            }
        } else if (newNode.isArray()) {
            for (JsonNode arrayElement : newNode) {
                // Recursively traverse and modify the array elements
                traverseAndModify(arrayElement, oldJson, null, null);
            }
        } else if (newNode.isValueNode()) {
            // Compare the leaf node (value) with all values in OldFormat
            boolean valueExists = valueExistsInJson(oldJson, newNode.asText());
            if (!valueExists && parentNode != null && fieldName != null) {
                parentNode.put(fieldName, "Value is not Present in OldJSON");
            }
        }
    }

    // Method to check if a value exists anywhere in OldFormat JSON
    public static boolean valueExistsInJson(JsonNode jsonNode, String value) {
        if (jsonNode.isObject()) {
            Iterator<String> fieldNames = jsonNode.fieldNames();
            while (fieldNames.hasNext()) {
                String fieldName = fieldNames.next();
                if (valueExistsInJson(jsonNode.get(fieldName), value)) {
                    return true;
                }
            }
        } else if (jsonNode.isArray()) {
            for (JsonNode arrayElement : jsonNode) {
                if (valueExistsInJson(arrayElement, value)) {
                    return true;
                }
            }
        } else if (jsonNode.isValueNode()) {
            return jsonNode.asText().equals(value);
        }
        return false;
    }
}
